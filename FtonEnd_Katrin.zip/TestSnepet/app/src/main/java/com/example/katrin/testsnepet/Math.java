package com.example.katrin.testsnepet;

import android.content.Intent;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.SeekBar;

public class Math extends AppCompatActivity {
    ImageView carr;
    SeekBar pbar;
    SeekBar pbar2;
    SeekBar pbar3;
    SeekBar pbar4;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_math);

        carr = (ImageView) findViewById(R.id.carr);
        pbar = (SeekBar) findViewById(R.id.pbar);
        pbar2 = (SeekBar) findViewById(R.id.pbar2);
        pbar3 = (SeekBar) findViewById(R.id.pbar3);
        pbar4 = (SeekBar) findViewById(R.id.pbar4);

        Animation anm = AnimationUtils.loadAnimation(this, R.anim.move);
        carr.startAnimation(anm);

        pbar.setMax(100);
        pbar.setProgress(0);

        final Thread thread = new Thread(){

            public void run(){
                try {
                    for (int i = 0; i <79; i++){
                        pbar.setProgress(i);
                        sleep(30);
                    }
                    for (int i = 0; i <65; i++){
                        pbar2.setProgress(i);
                        sleep(30);
                    }
                    for (int i = 0; i <90; i++){
                        pbar3.setProgress(i);
                        sleep(30);
                    }
                    for (int i = 0; i <27; i++){
                        pbar4.setProgress(i);
                        sleep(30);
                    }

                }catch (Exception e){
                    e.printStackTrace();
                }
            }
        };
        thread.start();

    }

}
